document.addEventListener('DOMContentLoaded', () => {
    const signInToggle = document.getElementById('sign-in-toggle');
    const signInForm = document.getElementById('sign-in-form');
    const closeForm = document.getElementById('close-form');

    signInToggle.addEventListener('click', (event) => {
        event.preventDefault();
        signInForm.style.display = signInForm.style.display === 'block' ? 'none' : 'block';
    });

    closeForm.addEventListener('click', () => {
        signInForm.style.display = 'none';
    });
});