document.getElementById('testimonial-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Example: Display a confirmation message
    alert('Thank you for submitting your testimonial!');

    // Clear the form fields
    this.reset();
});